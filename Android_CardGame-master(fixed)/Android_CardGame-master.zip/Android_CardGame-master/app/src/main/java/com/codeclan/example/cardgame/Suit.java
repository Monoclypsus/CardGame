package com.codeclan.example.cardgame;

/**
 * Created by user on 27/05/2017.
 */

public enum Suit {
    HEARTS,
    CLUBS,
    DIAMONDS,
    SPADES
}