# Android_CardGame
A card game android app developed in Java using Android studio. This
application compares the highest hand of two players and declares a winner.

This card game application was developed in Java using TDD on Android Studio. 
The user is shown a front page listing the rules and has an enter button to
enter the game. On entering the game the user is dealt cards for two
players making up two hands. Cards are randomly dealt from a full 
52 card deck in the Java code. Their images appear on the screen by tying up the
enums representing individual cards, the card gifs and the Android display code. 
The player selects four cards per hand. The java code adds up the rank total
of each hand and compares the two players' hands. A message comes on the screen
to inform the user which hand won the game.

I have downloaded this application onto my mobile phone and it works fine.
